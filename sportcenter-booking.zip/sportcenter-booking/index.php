<?php
require_once 'controllers/HomeController.php';
require_once 'controllers/BookingController.php';

$action = isset($_GET['action']) ? $_GET['action'] : 'home';

$homeController = new HomeController();
$bookingController = new BookingController();

switch ($action) {
    case 'home':
        $homeController->index();
        break;
    case 'book':
        $bookingController->create();
        break;
    case 'check_slots':
        $bookingController->checkSlots();
        break;
    case 'store_booking':
        $bookingController->store();
        break;
    default:
        $homeController->index();
        break;
}
?>