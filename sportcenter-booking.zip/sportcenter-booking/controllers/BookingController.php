<?php
require_once 'config/database.php';
require_once 'models/Field.php';
require_once 'models/Booking.php';

class BookingController {
    private $db;
    private $fieldModel;
    private $bookingModel;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->fieldModel = new Field($this->db);
        $this->bookingModel = new Booking($this->db);
    }

    // Menampilkan halaman form pemesanan berdasarkan ID lapangan
    public function create() {
        $field_id = isset($_GET['field_id']) ? $_GET['field_id'] : 1;
        $field = $this->fieldModel->getFieldById($field_id);

        if (!$field) {
            header("Location: index.php");
            exit();
        }

        include 'views/booking_form.php';
    }

    // AJAX Endpoint untuk mengecek slot jam yang sudah dibooking
    public function checkSlots() {
        if (isset($_GET['field_id']) && isset($_GET['date'])) {
            $field_id = $_GET['field_id'];
            $date = $_GET['date'];

            $bookedSlots = $this->bookingModel->getBookedSlots($field_id, $date);
            
            header('Content-Type: application/json');
            echo json_encode($bookedSlots);
            exit();
        }
    }

    // Memproses data form saat tombol booking diklik
    public function store() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $field_id = $_POST['field_id'];
            $customer_name = $_POST['customer_name'];
            $phone_number = $_POST['phone_number'];
            $booking_date = $_POST['booking_date'];
            $selected_slots = json_decode($_POST['selected_slots'], true); // Array slot jam dari JS
            $price_per_hour = $_POST['price_per_hour'];

            if (empty($selected_slots)) {
                echo json_encode(['success' => false, 'message' => 'Pilih minimal 1 slot jam!']);
                exit();
            }

            // Buat kode booking unik, misal: SCB-20261027-001
            $booking_code = 'SCB-' . date('Ymd') . '-' . rand(100, 999);
            $total_hours = count($selected_slots);
            $total_price = $total_hours * $price_per_hour;

            $dataBooking = [
                'booking_code' => $booking_code,
                'customer_name' => $customer_name,
                'phone_number' => $phone_number,
                'field_id' => $field_id,
                'booking_date' => $booking_date,
                'total_price' => $total_price
            ];

            $slotsData = [];
            foreach ($selected_slots as $slot) {
                // Format slot jam (misal: "08:00 - 09:00")
                $times = explode(' - ', $slot);
                $slotsData[] = [
                    'start_time' => $times[0] . ':00',
                    'end_time' => $times[1] . ':00',
                    'subtotal' => $price_per_hour
                ];
            }

            $result = $this->bookingModel->createBooking($dataBooking, $slotsData);

            header('Content-Type: application/json');
            echo json_encode($result);
            exit();
        }
    }
}
?>