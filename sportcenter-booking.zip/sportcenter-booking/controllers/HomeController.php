<?php
require_once 'config/database.php';
require_once 'models/Field.php';

class HomeController {
    private $db;
    private $fieldModel;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->fieldModel = new Field($this->db);
    }

    // Menampilkan halaman utama beserta katalog lapangan
    public function index() {
        $stmt = $this->fieldModel->getAllFields();
        $fields = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Panggil view home (akan kita buat nanti)
        include 'views/home.php';
    }
}
?>