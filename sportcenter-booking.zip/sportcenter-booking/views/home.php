<?php include 'views/layouts/header.php'; ?>

<!-- Hero Section -->
<header class="hero-section text-center py-5 position-relative overflow-hidden">
    <div class="container py-5">
        <span class="badge bg-neon text-dark fw-bold px-3 py-2 mb-3 text-uppercase tracking-wider">#1 Booking Arena Olahraga</span>
        <h1 class="display-4 fw-bold font-heading text-white mb-3">SEWA LAPANGAN TANPA <span class="text-neon">RIBET</span></h1>
        <p class="lead text-light mb-4 mx-auto" style="max-width: 600px;">
            Pesan jadwal lapangan futsal, basket, atau badminton secara online dengan mudah, cepat, dan transparan.
        </p>
        <a href="#katalog" class="btn btn-neon btn-lg px-4 py-3 fw-bold shadow-neon">
            <i class="fa-solid fa-calendar-check me-2"></i> Pilih Lapangan Sekarang
        </a>
    </div>
</header>

<!-- Katalog Lapangan Section -->
<section id="katalog" class="container py-5">
    <div class="row mb-5 text-center">
        <div class="col">
            <h2 class="fw-bold font-heading text-uppercase"><i class="fa-solid fa-layer-group text-neon me-2"></i> Katalog Lapangan</h2>
            <hr class="w-25 mx-auto border-neon opacity-100">
            <p class="text-muted">Pilih jenis lapangan dan fasilitas terbaik sesuai kebutuhan tim Anda.</p>
        </div>
    </div>

    <div class="row g-4">
        <?php if (!empty($fields)): ?>
            <?php foreach ($fields as $field): ?>
                <div class="col-md-4">
                    <div class="card bg-card-navy border-neon h-100 shadow-sm card-hover">
                        <div class="card-body d-flex flex-column">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <span class="badge bg-navy-custom border border-neon text-neon px-3 py-2">
                                    <i class="fa-solid fa-shield-halved me-1"></i> <?= htmlspecialchars($field['sport_type']); ?>
                                </span>
                                <span class="text-success fw-bold small"><i class="fa-solid fa-circle text-success fs-7 me-1"></i> Tersedia</span>
                            </div>
                            <h3 class="card-title fw-bold font-heading text-white fs-4 mb-2"><?= htmlspecialchars($field['field_name']); ?></h3>
                            <p class="text-muted small mb-4">Lantai berkualitas tinggi, pencahayaan terang, dan sirkulasi udara optimal untuk kenyamanan bertanding.</p>
                            
                            <div class="mt-auto">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <span class="text-muted small">Tarif Sewa:</span>
                                    <span class="text-neon fw-bold fs-5">Rp <?= number_format($field['price_per_hour'], 0, ',', '.'); ?> <span class="small text-muted font-normal">/jam</span></span>
                                </div>
                                <a href="index.php?action=book&field_id=<?= $field['field_id']; ?>" class="btn btn-neon w-100 fw-bold py-2">
                                    <i class="fa-solid fa-clock me-1"></i> Pilih Jadwal & Booking
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12 text-center py-5">
                <p class="text-muted">Belum ada lapangan yang tersedia saat ini.</p>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php include 'views/layouts/footer.php'; ?>