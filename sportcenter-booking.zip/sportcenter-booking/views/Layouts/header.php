<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SportCenter Booking - Sistem Pemesanan Lapangan Olahraga</title>
    <!-- Bootstrap CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Google Fonts: Poppins & Rajdhani (Sporty Vibe) -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Rajdhani:wght@600;700&display=swap" rel="stylesheet">
    <!-- FontAwesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-dark-navy text-light">

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-navy-custom border-bottom border-neon sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold font-heading fs-3 text-neon" href="index.php">
                <i class="fa-solid fa-bolt-lightning me-2"></i>SPORT<span class="text-white">CENTER</span>
            </a>
            <button class="navbar-toggler border-neon" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav align-items-center">
                    <li class="nav-item">
                        <a class="nav-link active" href="index.php"><i class="fa-solid fa-house me-1"></i> Beranda</a>
                    </li>
                    <li class="nav-item ms-lg-3 mt-2 mt-lg-0">
                        <a href="index.php#katalog" class="btn btn-neon-outline btn-sm px-3 py-2 fw-semibold">Pesan Lapangan</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>