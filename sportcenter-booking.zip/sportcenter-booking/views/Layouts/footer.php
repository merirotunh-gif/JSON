<!-- Footer -->
    <footer class="bg-navy-custom border-top border-neon py-4 mt-5">
        <div class="container text-center">
            <p class="mb-1 fw-medium">&copy; 2026 <strong>SportCenter Booking</strong>. All Rights Reserved.</p>
            <p class="text-muted small mb-0">Sistem Informasi Pemesanan Lapangan Olahraga Cepat & Terpercaya</p>
        </div>
    </footer>

    <!-- Bootstrap JS Bundle CDN -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- SweetAlert2 untuk Notifikasi Modern -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- Custom JS -->
    <script src="assets/js/script.js"></script>
</body>
</html>