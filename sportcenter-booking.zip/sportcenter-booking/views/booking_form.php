<?php include 'views/layouts/header.php'; ?>

<div class="container py-5">
    <!-- Breadcrumb / Back -->
    <div class="mb-4">
        <a href="index.php" class="text-decoration-none text-muted fw-semibold">
            <i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Katalog
        </a>
    </div>

    <div class="row g-4">
        <!-- Kolom Kiri: Pemilihan Tanggal & Slot Jam -->
        <div class="col-lg-8">
            <div class="card bg-card-navy border-neon p-4 shadow-sm">
                <h3 class="fw-bold font-heading mb-3">
                    <i class="fa-solid fa-calendar-days text-neon me-2"></i> Pilih Tanggal & Slot Jam
                </h3>
                <p class="text-muted small mb-4">Lapangan: <strong class="text-white"><?= htmlspecialchars($field['field_name']); ?></strong> (Rp <?= number_format($field['price_per_hour'], 0, ',', '.'); ?>/jam)</p>

                <!-- Input Tanggal -->
                <div class="mb-4">
                    <label for="booking_date" class="form-label fw-semibold text-light">Tanggal Sewa</label>
                    <input type="date" id="booking_date" class="form-control bg-dark-navy text-light border-neon" value="<?= date('Y-m-d'); ?>" min="<?= date('Y-m-d'); ?>">
                </div>

                <!-- Grid Slot Jam -->
                <div class="mb-3">
                    <label class="form-label fw-semibold text-light d-block mb-2">Pilih Jam Operasional (Klik untuk memilih/membatalkan)</label>
                    <div id="slot-container" class="row g-2">
                        <!-- Slot jam akan di-generate otomatis via JavaScript -->
                        <div class="col-12 text-center py-3 text-muted">Memuat slot jam...</div>
                    </div>
                </div>

                <!-- Keterangan Status -->
                <div class="d-flex gap-4 mt-3 small text-muted">
                    <span><i class="fa-solid fa-square text-secondary me-1"></i> Tersedia</span>
                    <span><i class="fa-solid fa-square text-neon me-1"></i> Dipilih</span>
                    <span><i class="fa-solid fa-square text-danger me-1"></i> Sudah Dipesan</span>
                </div>
            </div>
        </div>

        <!-- Kolom Kanan: Rincian & Form Pemesanan -->
        <div class="col-lg-4">
            <div class="card bg-card-navy border-neon p-4 shadow-sm sticky-top" style="top: 90px;">
                <h4 class="fw-bold font-heading mb-3 border-bottom border-neon pb-2">
                    <i class="fa-solid fa-receipt text-neon me-2"></i> Ringkasan Booking
                </h4>

                <form id="booking-form">
                    <input type="hidden" id="field_id" value="<?= $field['field_id']; ?>">
                    <input type="hidden" id="price_per_hour" value="<?= $field['price_per_hour']; ?>">
                    <input type="hidden" id="selected_slots_input" name="selected_slots">

                    <div class="mb-3">
                        <label for="customer_name" class="form-label small fw-semibold text-light">Nama Pemesan / Tim</label>
                        <input type="text" id="customer_name" name="customer_name" class="form-control bg-dark-navy text-light border-neon" placeholder="Contoh: FC Garuda" required>
                    </div>

                    <div class="mb-4">
                        <label for="phone_number" class="form-label small fw-semibold text-light">Nomor WhatsApp</label>
                        <input type="tel" id="phone_number" name="phone_number" class="form-control bg-dark-navy text-light border-neon" placeholder="Contoh: 081234567890" required>
                    </div>

                    <!-- Rincian Biaya -->
                    <div class="bg-dark-navy p-3 rounded border border-secondary mb-4">
                        <div class="d-flex justify-content-between mb-2 small">
                            <span class="text-muted">Total Slot:</span>
                            <span id="summary-hours" class="fw-bold text-white">0 Jam</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2 small">
                            <span class="text-muted">Tarif / Jam:</span>
                            <span class="text-white">Rp <?= number_format($field['price_per_hour'], 0, ',', '.'); ?></span>
                        </div>
                        <hr class="border-secondary my-2">
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="fw-bold text-light">Total Biaya:</span>
                            <span id="summary-total" class="fw-bold font-heading text-neon fs-4">Rp 0</span>
                        </div>
                    </div>

                    <button type="submit" id="btn-submit-booking" class="btn btn-neon w-100 fw-bold py-3 shadow-neon" disabled>
                        <i class="fa-solid fa-check-circle me-1"></i> Konfirmasi & Pesan Sekarang
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include 'views/layouts/footer.php'; ?>