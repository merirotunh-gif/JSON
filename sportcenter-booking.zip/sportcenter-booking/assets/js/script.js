document.addEventListener('DOMContentLoaded', function () {
    const slotContainer = document.getElementById('slot-container');
    const bookingDateInput = document.getElementById('booking_date');
    const fieldIdInput = document.getElementById('field_id');
    const pricePerHourInput = document.getElementById('price_per_hour');
    const summaryHours = document.getElementById('summary-hours');
    const summaryTotal = document.getElementById('summary-total');
    const selectedSlotsInput = document.getElementById('selected_slots_input');
    const btnSubmitBooking = document.getElementById('btn-submit-booking');
    const bookingForm = document.getElementById('booking-form');

    // Jika berada di halaman form pemesanan
    if (slotContainer && bookingDateInput) {
        const fieldId = fieldIdInput.value;
        const pricePerHour = parseFloat(pricePerHourInput.value);
        let selectedSlots = [];

        // Daftar jam operasional dari jam 08:00 sampai 22:00
        const operationalHours = [
            "08:00 - 09:00", "09:00 - 10:00", "10:00 - 11:00", "11:00 - 12:00",
            "12:00 - 13:00", "13:00 - 14:00", "14:00 - 15:00", "15:00 - 16:00",
            "16:00 - 17:00", "17:00 - 18:00", "18:00 - 19:00", "19:00 - 20:00",
            "20:00 - 21:00", "21:00 - 22:00"
        ];

        function loadSlots() {
            const selectedDate = bookingDateInput.value;
            slotContainer.innerHTML = '<div class="col-12 text-center py-3 text-muted">Memeriksa ketersediaan jadwal...</div>';
            selectedSlots = [];
            updateSummary();

            // Ambil data slot yang sudah dibooking dari server via AJAX
            fetch(`index.php?action=check_slots&field_id=${fieldId}&date=${selectedDate}`)
                .then(response => response.json())
                .then(bookedData => {
                    slotContainer.innerHTML = '';

                    operationalHours.forEach(slot => {
                        const times = slot.split(' - ');
                        const startTime = times[0] + ':00';
                        
                        // Cek apakah slot sudah dibooking orang lain
                        let isBooked = false;
                        bookedData.forEach(booked => {
                            if (booked.start_time === startTime) {
                                isBooked = true;
                            }
                        });

                        const colDiv = document.createElement('div');
                        colDiv.className = 'col-md-3 col-6';

                        const btn = document.createElement('button');
                        btn.type = 'button';
                        btn.className = 'btn slot-btn w-100 py-2 rounded';
                        btn.textContent = slot;

                        if (isBooked) {
                            btn.disabled = true;
                        } else {
                            btn.addEventListener('click', function () {
                                btn.classList.toggle('selected');
                                if (btn.classList.contains('selected')) {
                                    selectedSlots.push(slot);
                                } else {
                                    selectedSlots = selectedSlots.filter(s => s !== slot);
                                }
                                updateSummary();
                            });
                        }

                        colDiv.appendChild(btn);
                        slotContainer.appendChild(colDiv);
                    });
                })
                .catch(error => {
                    console.error('Error:', error);
                    slotContainer.innerHTML = '<div class="col-12 text-center py-3 text-danger">Gagal memuat slot jam.</div>';
                });
        }

        function updateSummary() {
            const totalHours = selectedSlots.length;
            const totalPrice = totalHours * pricePerHour;

            summaryHours.textContent = totalHours + ' Jam';
            summaryTotal.textContent = 'Rp ' + totalPrice.toLocaleString('id-ID');
            selectedSlotsInput.value = JSON.stringify(selectedSlots);

            if (totalHours > 0) {
                btnSubmitBooking.removeAttribute('disabled');
            } else {
                btnSubmitBooking.setAttribute('disabled', 'true');
            }
        }

        // Event saat tanggal diubah
        bookingDateInput.addEventListener('change', loadSlots);

        // Load awal saat halaman dibuka
        loadSlots();

        // Handle Submit Form Pemesanan
        bookingForm.addEventListener('submit', function (e) {
            e.preventDefault();

            const formData = new FormData(bookingForm);
            formData.append('field_id', fieldId);
            formData.append('booking_date', bookingDateInput.value);
            formData.append('price_per_hour', pricePerHour);
            formData.append('selected_slots', selectedSlotsInput.value);

            Swal.fire({
                title: 'Konfirmasi Pemesanan',
                text: 'Pastikan jadwal dan data diri Anda sudah benar.',
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#00ff88',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ya, Pesan Sekarang!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch('index.php?action=store_booking', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            Swal.fire({
                                title: 'Booking Berhasil!',
                                html: `Kode Booking Anda: <strong class="text-neon">${data.booking_code}</strong><br>Silakan lakukan pembayaran ke kasir SportCenter atau via transfer.`,
                                icon: 'success',
                                confirmButtonColor: '#00ff88'
                            }).then(() => {
                                window.location.href = 'index.php';
                            });
                        } else {
                            Swal.fire('Gagal!', data.message || 'Terjadi kesalahan sistem.', 'error');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        Swal.fire('Error!', 'Gagal menghubungi server.', 'error');
                    });
                }
            });
        });
    }
});