<?php
class Field {
    private $conn;
    private $table_name = "fields";

    public function __construct($db) {
        $this->conn = $db;
    }

    // Mengambil semua data lapangan yang aktif
    public function getAllFields() {
        $query = "SELECT * FROM " . $this->table_name . " WHERE is_active = 1";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    // Mengambil detail satu lapangan berdasarkan ID
    public function getFieldById($field_id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE field_id = ? LIMIT 0,1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $field_id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
?>