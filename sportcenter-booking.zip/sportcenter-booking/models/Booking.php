<?php
class Booking {
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    // Cek slot jam yang sudah dipesan pada tanggal dan lapangan tertentu
    public function getBookedSlots($field_id, $booking_date) {
        $query = "SELECT bd.start_time, bd.end_time 
                  FROM booking_details bd
                  JOIN bookings b ON bd.booking_id = b.booking_id
                  WHERE b.field_id = :field_id 
                    AND b.booking_date = :booking_date 
                    AND b.booking_status IN ('pending', 'confirmed')";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':field_id', $field_id);
        $stmt->bindParam(':booking_date', $booking_date);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Simpan data pemesanan baru beserta detail slot jam-nya
    public function createBooking($data, $slots) {
        try {
            // Mulai Database Transaction untuk keamanan data
            $this->conn->beginTransaction();

            // 1. Insert ke tabel bookings (Header)
            $queryBooking = "INSERT INTO bookings (booking_code, customer_name, phone_number, field_id, booking_date, total_price, booking_status) 
                             VALUES (:booking_code, :customer_name, :phone_number, :field_id, :booking_date, :total_price, 'confirmed')";
            
            $stmt = $this->conn->prepare($queryBooking);
            $stmt->bindParam(':booking_code', $data['booking_code']);
            $stmt->bindParam(':customer_name', $data['customer_name']);
            $stmt->bindParam(':phone_number', $data['phone_number']);
            $stmt->bindParam(':field_id', $data['field_id']);
            $stmt->bindParam(':booking_date', $data['booking_date']);
            $stmt->bindParam(':total_price', $data['total_price']);
            $stmt->execute();

            $booking_id = $this->conn->lastInsertId();

            // 2. Insert ke tabel booking_details (Slot jam yang dipilih)
            $queryDetail = "INSERT INTO booking_details (booking_id, start_time, end_time, subtotal) 
                            VALUES (:booking_id, :start_time, :end_time, :subtotal)";
            $stmtDetail = $this->conn->prepare($queryDetail);

            foreach ($slots as $slot) {
                $stmtDetail->bindParam(':booking_id', $booking_id);
                $stmtDetail->bindParam(':start_time', $slot['start_time']);
                $stmtDetail->bindParam(':end_time', $slot['end_time']);
                $stmtDetail->bindParam(':subtotal', $slot['subtotal']);
                $stmtDetail->execute();
            }

            // Commit transaksi jika semua berhasil
            $this->conn->commit();
            return ['success' => true, 'booking_code' => $data['booking_code']];

        } catch (Exception $e) {
            // Rollback jika terjadi error
            $this->conn->rollBack();
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
}
?>